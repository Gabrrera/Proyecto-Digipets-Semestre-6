// Login.js
import React from 'react';

const Login = () => {
    return (
        <div>
            <h2>Login</h2>
            {/* Formulario de inicio de sesión */}
        </div>
    );
}

export default Login;
