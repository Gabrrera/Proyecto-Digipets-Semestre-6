// Register.js
import React from 'react';

const Register = () => {
    return (
        <div>
            <h2>Register</h2>
            {/* Formulario de registro */}
        </div>
    );
}

export default Register;
